<?php
add_theme_support( 'post-thumbnails' );//image à la une

if ( function_exists('register_sidebar') ) register_sidebar();

?>