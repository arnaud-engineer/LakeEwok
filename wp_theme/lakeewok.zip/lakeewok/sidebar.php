<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>

<!--<div class="sidebar">
	<ul>
	</ul>
</div>-->

<?php endif; ?>