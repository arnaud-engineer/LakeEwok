<header>
    <h1><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo('name'); ?></a></h1><hr/>
    <h2 id='deadline'><!--VOUS DEVRIEZ ACTIVEZ JAVASCRIPT : <a href="http://www.enable-javascript.com/fr/">CLIQUEZ ICI !</a>--><?php bloginfo('description'); ?></h2><hr/>
</header>