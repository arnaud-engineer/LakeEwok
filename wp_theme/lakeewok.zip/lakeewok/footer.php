<footer>

	<div id="tools">

		<div id="social">
			<a href="feed:<?php bloginfo('rss2_url'); ?>"><img src="<?php bloginfo('template_directory'); ?>/rss.png" title="rss-icon" alt="icone du flux rss" style="width:20px;height:20px;" /></a>&nbsp;&nbsp;

			<a href="http://twitter.com/nanaud"><img src="<?php bloginfo('template_directory'); ?>/twitter.png" title="twitter-icon" alt="icone de twitter" style="width:20px;height:20px;" /></a>&nbsp;&nbsp;

			<a href="http://facebook.com/nanaud"><img src="<?php bloginfo('template_directory'); ?>/facebook.png" title="facebook-icon" alt="icone de facebook" style="width:20px;height:20px;" /></a>&nbsp;&nbsp;
		</div>

		<div id="search">
			<?php include(TEMPLATEPATH . '/searchform.php'); ?>
		</div>
	</div>

	<div id="credit">
		Édité et Designé par <a href="http://nanaud.fr">@Nanaud</a>
	</div> 
</footer>
